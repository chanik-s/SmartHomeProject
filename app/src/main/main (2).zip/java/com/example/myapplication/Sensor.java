package com.example.myapplication;

// php에서 json 파싱한 값 저장할 클래스(sensor) 만듦
public class Sensor {
    String humidity;
    String temperature;
    String time;

    String PM;
    public String getHumidity(){
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPM() {
        return PM;
    }

    public void setPM(String PM) {
        this.PM = PM;
    }
}
